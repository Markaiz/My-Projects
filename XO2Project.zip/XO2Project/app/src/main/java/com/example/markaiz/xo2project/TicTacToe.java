package com.example.markaiz.xo2project;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;

import com.example.markaiz.xo2project.strategies.Board;


public class TicTacToe extends Activity implements OnClickListener {


    private View exitButton;
    private View mediumButton;


    /**
     * Called when the activity is first created.
     */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);


        mediumButton = findViewById(R.id.MediumDifficulty);
        mediumButton.setOnClickListener(this);


        exitButton = findViewById(R.id.exitButton);
        exitButton.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {

            case R.id.MediumDifficulty:
                Game.ticTacToeStrategy = new Board();
                newGameDialog();
                break;

            case R.id.exitButton:
                finish();
                break;
        }
    }

    private void newGameDialog() {
        new AlertDialog.Builder(this)
                .setTitle(R.string.whosFirstLabel)
                .setItems(R.array.whosFirst,
                        new DialogInterface.OnClickListener() {
                            public void onClick(
                                    DialogInterface dialoginterface, int i) {
                                startGame(i);
                            }
                        }).show();
    }

    /**
     * @param i - 0 AI moves first, 1 User moves first
     */
    private void startGame(int i) {
        Intent intent = new Intent(TicTacToe.this, Game.class);
        intent.putExtra(Game.PLAYER, i);
        startActivity(intent);
    }
}
